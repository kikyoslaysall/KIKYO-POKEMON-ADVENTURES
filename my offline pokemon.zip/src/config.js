import './style.css';

const starters = [
 {id:'bulbasaur',name:'Bulbasaur',emoji:'🌱',type:'GRASS',hp:45,attack:9,level:5},
 {id:'charmander',name:'Charmander',emoji:'🔥',type:'FIRE',hp:39,attack:11,level:5},
 {id:'squirtle',name:'Squirtle',emoji:'💧',type:'WATER',hp:44,attack:10,level:5}
];

const wildPokemon = [
 {id:'pikachu',name:'Pikachu',emoji:'⚡',type:'ELECTRIC',hp:34,attack:10,level:4},
 {id:'pidgey',name:'Pidgey',emoji:'🐦',type:'FLYING',hp:32,attack:7,level:3},
 {id:'rattata',name:'Rattata',emoji:'🐭',type:'NORMAL',hp:30,attack:8,level:3},
 {id:'caterpie',name:'Caterpie',emoji:'🐛',type:'BUG',hp:28,attack:6,level:2},
 {id:'oddish',name:'Oddish',emoji:'🌿',type:'GRASS',hp:35,attack:7,level:4}
];

const load = () => {
 try {
  return JSON.parse(localStorage.getItem('kikyo-save')) || {};
 } catch {
  return {};
 }
};

let save = {
 name:'Trainer',
 level:1,
 xp:0,
 coins:300,
 region:'Kanto',
 party:[],
 dex:[],
 balls:5,
 wins:0,
 ...load()
};

let wild = null;
let tab = 'home';
let message = '';

function persist(){
 localStorage.setItem('kikyo-save',JSON.stringify(save));
}

function button(label,action){
 return `<button onclick="${action}">${label}</button>`;
}

function starterScreen(){
 return `
 <section class="welcome">
 <div class="logo">⚡ KIKYO ⚡</div>
 <h1>Pokémon Adventures</h1>
 <p>Choose your first Pokémon!</p>
 <input id="trainer" placeholder="Trainer name" value="${save.name==='Trainer'?'':save.name}">
 <div class="starters">
 ${starters.map((p,i)=>`
 <button onclick="chooseStarter(${i})">
 <span>${p.emoji}</span>
 <b>${p.name}</b>
 <small>${p.type}</small>
 </button>`).join('')}
 </div>
 </section>`;
}

function chooseStarter(i){
 const p={...starters[i]};
 save.name=document.getElementById('trainer').value.trim()||'Trainer';
 save.party=[p];
 save.dex=[p.id];
 persist();
 render();
}

function navigation(){
 return `
 <nav>
 ${['home','explore','team','pokedex','profile'].map(t=>
 `<button class="${tab===t?'active':''}" onclick="go('${t}')">${t}</button>`
 ).join('')}
 </nav>`;
}

function home(){
 return `
 <section class="hero">
 <small>WELCOME BACK, ${save.name.toUpperCase()}</small>
 <h1>Your adventure<br>begins here.</h1>
 <div class="hero-pokemon">${save.party[0]?.emoji||'⚡'}</div>
 <button onclick="go('explore')">EXPLORE REGION →</button>
 </section>
 <div class="stats">
 <div>LEVEL<b>${save.level}</b></div>
 <div>POKÉMON<b>${save.party.length}/6</b></div>
 <div>WINS<b>${save.wins}</b></div>
 </div>
 <h2>Your team</h2>
 ${save.party.slice(0,2).map(p=>monCard(p)).join('')}
 `;
}

function monCard(p){
 return `<div class="pokemon-card">
 <span>${p.emoji}</span>
 <div><b>${p.name}</b><small>${p.type} · Lv.${p.level}</small></div>
 </div>`;
}

function explore(){
 return `
 <h1>Explore ${save.region}</h1>
 <div class="location">
 <span>🌳</span>
 <h2>Route 1</h2>
 <p>Search the grass for wild Pokémon!</p>
 </div>
 <p>🔴 Poké Balls: ${save.balls}</p>
 <button onclick="encounter()">SEARCH THE GRASS</button>
 ${wild?battle():''}
 <h2>Regions</h2>
 <div class="regions">
 ${['Kanto','Johto','Hoenn','Sinnoh'].map(r=>
 `<button onclick="changeRegion('${r}')">${r}</button>`).join('')}
 </div>
 `;
}

function encounter(){
 wild={...wildPokemon[Math.floor(Math.random()*wildPokemon.length)]};
 wild.maxHp=wild.hp;
 message=`A wild ${wild.name} appeared!`;
 render();
}

function battle(){
 return `
 <div class="battle">
 <h2>⚔️ WILD ${wild.name.toUpperCase()}</h2>
 <div class="battle-emoji">${wild.emoji}</div>
 <p>HP: ${wild.hp}/${wild.maxHp}</p>
 <p>${message}</p>
 <button onclick="attack()">ATTACK</button>
 <button onclick="catchPokemon()">CATCH</button>
 <button onclick="runAway()">RUN</button>
 </div>`;
}

function attack(){
 const p=save.party[0];
 wild.hp-=p.attack;
 if(wild.hp<=0){
  message=`You defeated ${wild.name}!`;
  save.wins++;
  save.xp+=20;
  save.coins+=15;
  if(save.xp>=100){save.level++;save.xp-=100;}
  wild=null;
 }else{
  message=`${p.name} attacked!`;
  wild.hp-=Math.floor(wild.attack/2);
  if(wild.hp<=0){
   save.wins++;
   save.xp+=20;
   save.coins+=15;
   wild=null;
  }
 }
 persist();
 render();
}

function catchPokemon(){
 if(save.balls<=0){message='No Poké Balls left!';render();return;}
 save.balls--;
 if(Math.random()<0.65 && save.party.length<6){
  save.party.push({...wild});
  if(!save.dex.includes(wild.id))save.dex.push(wild.id);
  message=`${wild.name} joined your team!`;
  wild=null;
 }else{
  message='The Pokémon escaped!';
 }
 persist();
 render();
}

function runAway(){wild=null;render();}

function team(){
 return `<h1>Your Pokémon Team</h1>
 ${save.party.map(monCard).join('')||'No Pokémon yet.'}`;
}

function pokedex(){
 return `<h1>Pokédex</h1>
 <p>${save.dex.length} discovered Pokémon</p>
 ${[...starters,...wildPokemon].map(p=>
 `<div class="dex">${save.dex.includes(p.id)?p.emoji+' '+p.name:'❔ Unknown'}</div>`
 ).join('')}`;
}

function profile(){
 return `<h1>Trainer Profile</h1>
 <div class="profile">
 <div class="avatar">🧢</div>
 <h2>${save.name}</h2>
 <p>Level ${save.level}</p>
 <p>XP ${save.xp}/100</p>
 <p>Coins 🪙 ${save.coins}</p>
 <p>Victories ${save.wins}</p>
 <button onclick="rename()">CHANGE NAME</button>
 <button onclick="resetGame()">RESET GAME</button>
 </div>`;
}

function rename(){
 const n=prompt('New trainer name');
 if(n?.trim()){save.name=n.trim().slice(0,16);persist();render();}
}

function resetGame(){
 if(confirm('Delete all local game progress?')){
 localStorage.removeItem('kikyo-save');
 location.reload();
 }
}

function changeRegion(r){save.region=r;persist();render();}
function go(t){tab=t;render();}

function render(){
 const app=document.getElementById('app');
 if(!save.party.length){app.innerHTML=starterScreen();return;}
 let content={home,explore,team,pokedex,profile}[tab]();
 app.innerHTML=`
 <header><b>KIKYO</b><span>POKÉMON ADVENTURES</span></header>
 <main>${content}</main>
 ${navigation()}
 `;
}

window.chooseStarter=chooseStarter;
window.go=go;
window.encounter=encounter;
window.attack=attack;
window.catchPokemon=catchPokemon;
window.runAway=runAway;
window.changeRegion=changeRegion;
window.rename=rename;
window.resetGame=resetGame;

render();